import { useState } from "react";
import { toast } from "sonner";
import { ChevronDown, ChevronUp, Plus, Trash2, Percent, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import type { DbProfessional, DbCommissionRule, DbService, DbBusiness } from "@/lib/database";

interface CommissionSectionProps {
  prof: DbProfessional;
  business: DbBusiness;
  commissionRules: DbCommissionRule[];
  onReload: () => Promise<void>;
}

type CommissionType = "percentage" | "fixed";

interface RuleFormState {
  type: CommissionType;
  value: string;
}

const EMPTY_FORM: RuleFormState = { type: "percentage", value: "" };

function formatRuleValue(rule: DbCommissionRule) {
  if (rule.type === "percentage") return `${rule.value}%`;
  return `R$ ${Number(rule.value).toFixed(2).replace(".", ",")}`;
}

function RuleRow({
  rule,
  label,
  onEdit,
  onDelete,
  isEditing,
  form,
  setForm,
  saving,
  onSave,
  onCancel,
}: {
  rule?: DbCommissionRule;
  label: string;
  onEdit: () => void;
  onDelete: () => void;
  isEditing: boolean;
  form: RuleFormState;
  setForm: (f: RuleFormState) => void;
  saving: boolean;
  onSave: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="rounded-lg border border-border/40 bg-muted/20 px-3 py-2.5 space-y-2">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-muted-foreground truncate">{label}</span>
        <div className="flex items-center gap-1 shrink-0">
          {rule ? (
            <>
              <span className="text-xs font-semibold text-amber-600 mr-1">{formatRuleValue(rule)}</span>
              <button
                className="text-[11px] text-muted-foreground hover:text-foreground transition-colors px-1.5 py-0.5 rounded"
                onClick={onEdit}
              >
                Editar
              </button>
              <button
                className="text-[11px] text-destructive hover:text-destructive/80 transition-colors px-1.5 py-0.5 rounded"
                onClick={onDelete}
              >
                Remover
              </button>
            </>
          ) : (
            <button
              className="text-[11px] text-primary hover:text-primary/80 transition-colors px-1.5 py-0.5 rounded flex items-center gap-1"
              onClick={onEdit}
            >
              <Plus className="h-2.5 w-2.5" /> Definir
            </button>
          )}
        </div>
      </div>

      {isEditing && (
        <div className="flex flex-wrap gap-1.5 items-center pt-1 border-t border-border/30">
          <Select
            value={form.type}
            onValueChange={(v) => setForm({ ...form, type: v as CommissionType })}
          >
            <SelectTrigger className="h-7 text-xs w-28">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="percentage">
                <span className="flex items-center gap-1.5"><Percent className="h-3 w-3" /> Percentual</span>
              </SelectItem>
              <SelectItem value="fixed">
                <span className="flex items-center gap-1.5"><DollarSign className="h-3 w-3" /> Fixo (R$)</span>
              </SelectItem>
            </SelectContent>
          </Select>
          <Input
            type="number"
            min="0"
            max={form.type === "percentage" ? "100" : undefined}
            step="0.01"
            placeholder={form.type === "percentage" ? "Ex: 30" : "Ex: 15,00"}
            value={form.value}
            onChange={(e) => setForm({ ...form, value: e.target.value })}
            className="h-7 text-xs w-24"
            onKeyDown={(e) => { if (e.key === "Enter") onSave(); if (e.key === "Escape") onCancel(); }}
            autoFocus
          />
          <Button
            size="sm"
            className="h-7 text-xs bg-gradient-gold text-primary-foreground hover:opacity-90 px-2.5"
            onClick={onSave}
            disabled={saving}
          >
            {saving ? "..." : "Salvar"}
          </Button>
          <button
            className="text-xs text-muted-foreground hover:text-foreground px-1.5"
            onClick={onCancel}
          >
            Cancelar
          </button>
        </div>
      )}
    </div>
  );
}

export default function CommissionSection({
  prof,
  business,
  commissionRules,
  onReload,
}: CommissionSectionProps) {
  const [expanded, setExpanded] = useState(false);
  // editingKey: null | "general" | service_id
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [form, setForm] = useState<RuleFormState>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  // Rules for this professional
  const profRules = commissionRules.filter((r) => r.professional_id === prof.id);
  const generalRule = profRules.find((r) => r.service_id === null);

  // Services assigned to this professional (or all if serves_all_services)
  const relevantServices: DbService[] = prof.serves_all_services
    ? business.services
    : business.services.filter((s) =>
        (business.professional_services || []).some(
          (ps) => ps.professional_id === prof.id && ps.service_id === s.id
        )
      );

  const totalRules = profRules.length;
  const hasAnyRule = totalRules > 0;

  function startEdit(key: string, existing?: DbCommissionRule) {
    setEditingKey(key);
    setForm(existing ? { type: existing.type, value: String(existing.value) } : EMPTY_FORM);
  }

  function cancelEdit() {
    setEditingKey(null);
    setForm(EMPTY_FORM);
  }

  async function handleSave(serviceId: string | null) {
    const val = parseFloat(form.value.replace(",", "."));
    if (isNaN(val) || val < 0) { toast.error("Informe um valor válido."); return; }
    if (form.type === "percentage" && val > 100) { toast.error("Percentual não pode exceder 100%."); return; }

    setSaving(true);
    try {
      const { data, error } = await supabase.rpc("set_commission_rule" as any, {
        p_business_id:     business.id,
        p_professional_id: prof.id,
        p_type:            form.type,
        p_value:           val,
        p_service_id:      serviceId,
      });
      if (error) throw error;
      const res = data as any;
      if (res?.error) { toast.error(res.error); return; }
      toast.success("Comissão salva!");
      cancelEdit();
      await onReload();
    } catch (err: any) {
      toast.error(err.message || "Erro ao salvar comissão.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(ruleId: string) {
    try {
      await supabase.rpc("delete_commission_rule" as any, {
        p_rule_id: ruleId,
        p_business_id: business.id,
      });
      await onReload();
      toast.success("Comissão removida.");
    } catch {
      toast.error("Erro ao remover.");
    }
  }

  return (
    <div className="mt-3 pt-3 border-t border-border/50">
      {/* Header toggle */}
      <button
        className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors w-full"
        onClick={() => setExpanded(!expanded)}
      >
        <Percent className="h-3.5 w-3.5 shrink-0" />
        <span>Comissões</span>
        {hasAnyRule && (
          <span className="ml-1 rounded-full bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-medium text-amber-600">
            {totalRules} regra{totalRules !== 1 ? "s" : ""}
          </span>
        )}
        {expanded ? <ChevronUp className="h-3 w-3 ml-auto" /> : <ChevronDown className="h-3 w-3 ml-auto" />}
      </button>

      {expanded && (
        <div className="mt-2.5 space-y-2">
          {/* General rule */}
          <div>
            <p className="text-[10px] font-semibold text-muted-foreground/60 uppercase tracking-wider mb-1.5">
              Regra geral
            </p>
            <RuleRow
              rule={generalRule}
              label="Todos os serviços (padrão)"
              onEdit={() => startEdit("general", generalRule)}
              onDelete={() => generalRule && handleDelete(generalRule.id)}
              isEditing={editingKey === "general"}
              form={form}
              setForm={setForm}
              saving={saving}
              onSave={() => handleSave(null)}
              onCancel={cancelEdit}
            />
          </div>

          {/* Per-service rules */}
          {relevantServices.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold text-muted-foreground/60 uppercase tracking-wider mb-1.5 mt-3">
                Por serviço
                <span className="normal-case font-normal ml-1 text-muted-foreground/40">(substitui regra geral)</span>
              </p>
              <div className="space-y-1.5">
                {relevantServices.map((svc) => {
                  const svcRule = profRules.find((r) => r.service_id === svc.id);
                  return (
                    <RuleRow
                      key={svc.id}
                      rule={svcRule}
                      label={svc.name}
                      onEdit={() => startEdit(svc.id, svcRule)}
                      onDelete={() => svcRule && handleDelete(svcRule.id)}
                      isEditing={editingKey === svc.id}
                      form={form}
                      setForm={setForm}
                      saving={saving}
                      onSave={() => handleSave(svc.id)}
                      onCancel={cancelEdit}
                    />
                  );
                })}
              </div>
            </div>
          )}

          {relevantServices.length === 0 && !prof.serves_all_services && (
            <p className="text-xs text-muted-foreground/50 py-1">
              Nenhum serviço atribuído. Atribua serviços para definir comissões específicas.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
