import { useState, useEffect, useMemo, useCallback } from "react";
import { toast } from "sonner";
import { Plus, Trash2, UserCheck, UserX, Mail, Link2, ChevronDown, ChevronUp, UserCog, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import {
  DbBusiness,
  DbProfessional,
  DbProfessionalService,
  DbStaffInvite,
  DbCommissionRule,
  DbService,
  addProfessional,
  updateProfessional,
  deleteProfessional,
  setProfessionalServiceAssignments,
} from "@/lib/database";
import CommissionSection from "./CommissionSection";

interface ProfessionalsTabProps {
  business: DbBusiness;
  setBusiness: React.Dispatch<React.SetStateAction<DbBusiness | null>>;
}

const DAYS_FULL = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];

const ROLE_LABELS: Record<string, string> = { gerente: "Gerente", barbeiro: "Barbeiro" };
const ROLE_COLORS: Record<string, string> = {
  gerente: "text-blue-600 bg-blue-500/15 border-blue-500/30",
  barbeiro: "text-primary bg-primary/15 border-primary/30",
};

const ProfessionalsTab = ({ business, setBusiness }: ProfessionalsTabProps) => {
  const [newName, setNewName] = useState("");
  const [newStart, setNewStart] = useState(business.working_hours_start);
  const [newEnd, setNewEnd] = useState(business.working_hours_end);
  const [adding, setAdding] = useState(false);
  const [savingId, setSavingId] = useState<string | null>(null);

  // Extra hours state
  type ExtraHourRow = { id: string; day_of_week: number; open_time: string; close_time: string };
  const [extraHoursMap, setExtraHoursMap] = useState<Record<string, ExtraHourRow[]>>({});
  const [extraExpandedId, setExtraExpandedId] = useState<string | null>(null);
  const [newExtraDay, setNewExtraDay] = useState(6);
  const [newExtraStart, setNewExtraStart] = useState("14:00");
  const [newExtraEnd, setNewExtraEnd] = useState("18:00");
  const [savingExtra, setSavingExtra] = useState<string | null>(null);

  const loadExtraHours = useCallback(async () => {
    const { data } = await supabase
      .from("professional_hours" as any)
      .select("id, professional_id, day_of_week, open_time, close_time")
      .eq("business_id", business.id)
      .eq("is_extra", true);
    const map: Record<string, ExtraHourRow[]> = {};
    for (const row of (data as any[]) || []) {
      if (!map[row.professional_id]) map[row.professional_id] = [];
      map[row.professional_id].push(row);
    }
    setExtraHoursMap(map);
  }, [business.id]);

  useEffect(() => { loadExtraHours(); }, [loadExtraHours]);

  const handleAddExtra = async (profId: string) => {
    if (!newExtraStart || !newExtraEnd || newExtraStart >= newExtraEnd) {
      toast.error("Horário inválido — início deve ser anterior ao fim.");
      return;
    }
    setSavingExtra(profId);
    try {
      const { data, error } = await supabase
        .from("professional_hours" as any)
        .insert({
          business_id: business.id,
          professional_id: profId,
          day_of_week: newExtraDay,
          open_time: newExtraStart,
          close_time: newExtraEnd,
          is_extra: true,
          is_closed: false,
        })
        .select("id, professional_id, day_of_week, open_time, close_time")
        .single();
      if (error) throw error;
      setExtraHoursMap(prev => ({
        ...prev,
        [profId]: [...(prev[profId] || []), data as ExtraHourRow],
      }));
      toast.success("Horário extra adicionado!");
    } catch (err: any) {
      toast.error(err.message || "Erro ao salvar horário extra.");
    } finally {
      setSavingExtra(null);
    }
  };

  const handleRemoveExtra = async (profId: string, rowId: string) => {
    try {
      await supabase
        .from("professional_hours" as any)
        .delete()
        .eq("id", rowId)
        .eq("business_id", business.id);
      setExtraHoursMap(prev => ({
        ...prev,
        [profId]: (prev[profId] || []).filter(h => h.id !== rowId),
      }));
      toast.success("Horário extra removido.");
    } catch {
      toast.error("Erro ao remover horário extra.");
    }
  };

  // Commission rules state
  const [commissionRules, setCommissionRules] = useState<import("@/lib/database").DbCommissionRule[]>([]);

  const loadCommissions = useCallback(async () => {
    const { data } = await supabase.rpc("get_commission_rules" as any, { p_business_id: business.id });
    setCommissionRules((data as unknown as import("@/lib/database").DbCommissionRule[]) ?? []);
  }, [business.id]);

  useEffect(() => { loadCommissions(); }, [loadCommissions]);

  // Staff invites state
  const [staffInvites, setStaffInvites] = useState<DbStaffInvite[]>([]);
  const [inviteExpandedId, setInviteExpandedId] = useState<string | null>(null);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<"gerente" | "barbeiro">("barbeiro");
  const [inviting, setInviting] = useState<string | null>(null);
  const [revoking, setRevoking] = useState<string | null>(null);

  const loadInvites = useCallback(async () => {
    const { data } = await supabase.rpc("get_staff_invites" as any, {
      p_business_id: business.id,
    });
    setStaffInvites((data as unknown as DbStaffInvite[]) ?? []);
  }, [business.id]);

  useEffect(() => { loadInvites(); }, [loadInvites]);

  const handleInvite = async (prof: DbProfessional) => {
    if (!inviteEmail.trim()) { toast.error("Informe o e-mail."); return; }
    setInviting(prof.id);
    try {
      const { data, error } = await supabase.rpc("create_staff_invite" as any, {
        p_business_id:     business.id,
        p_email:           inviteEmail.trim(),
        p_role:            inviteRole,
        p_professional_id: prof.id,
      });
      if (error) throw error;
      const res = data as any;
      if (res?.error) { toast.error(res.error); return; }
      toast.success("Convite criado!");
      setInviteEmail("");
      setInviteExpandedId(null);
      await loadInvites();
    } catch (err: any) {
      toast.error(err.message || "Erro ao criar convite.");
    } finally {
      setInviting(null);
    }
  };

  const handleRevoke = async (inviteId: string) => {
    setRevoking(inviteId);
    try {
      const { data, error } = await supabase.rpc("revoke_staff_invite" as any, {
        p_invite_id:   inviteId,
        p_business_id: business.id,
      });
      if (error) throw error;
      const res = data as any;
      if (res?.error) { toast.error(res.error); return; }
      toast.success("Acesso revogado.");
      await loadInvites();
    } catch {
      toast.error("Erro ao revogar acesso.");
    } finally {
      setRevoking(null);
    }
  };

  const copyInviteLink = (token: string) => {
    const url = `${window.location.origin}/convite/${token}`;
    navigator.clipboard.writeText(url);
    toast.success("Link copiado!");
  };

  useEffect(() => {
    setNewStart(business.working_hours_start);
    setNewEnd(business.working_hours_end);
    setNewName("");
  }, [business.id, business.working_hours_start, business.working_hours_end]);

  const servicesByProfessional = useMemo(() => {
    const map = new Map<string, string[]>();
    for (const prof of business.professionals || []) {
      map.set(
        prof.id,
        (business.professional_services || [])
          .filter((ps) => ps.professional_id === prof.id)
          .map((ps) => ps.service_id)
      );
    }
    return map;
  }, [business.professional_services, business.professionals]);

  const handleAdd = async () => {
    if (!newName.trim()) return;
    setAdding(true);
    try {
      const prof = await addProfessional({
        business_id: business.id,
        name: newName.trim(),
        working_hours_start: newStart,
        working_hours_end: newEnd,
      });

      setBusiness((prev) =>
        prev
          ? {
              ...prev,
              professionals: [...(prev.professionals || []), { ...prof, serves_all_services: (prof as any).serves_all_services ?? true }],
            }
          : prev
      );
      setNewName("");
      toast.success("Profissional adicionado!");
    } catch (err: any) {
      toast.error("Erro: " + (err.message || "tente novamente"));
    } finally {
      setAdding(false);
    }
  };

  const handleToggle = async (prof: DbProfessional) => {
    try {
      await updateProfessional(prof.id, { active: !prof.active }, business.id);
      setBusiness((prev) =>
        prev
          ? {
              ...prev,
              professionals: prev.professionals.map((p) => (p.id === prof.id ? { ...p, active: !p.active } : p)),
            }
          : prev
      );
    } catch {
      toast.error("Erro ao atualizar.");
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteProfessional(id, business.id);
      setBusiness((prev) =>
        prev
          ? {
              ...prev,
              professionals: prev.professionals.filter((p) => p.id !== id),
              professional_services: (prev.professional_services || []).filter((ps) => ps.professional_id !== id),
            }
          : prev
      );
      toast.success("Profissional removido.");
    } catch {
      toast.error("Erro ao remover.");
    }
  };

  const saveAssignments = async (prof: DbProfessional, servesAllServices: boolean, serviceIds: string[]) => {
    setSavingId(prof.id);
    try {
      await setProfessionalServiceAssignments({
        businessId: business.id,
        professionalId: prof.id,
        servesAllServices,
        serviceIds,
      });

      const nextRows: DbProfessionalService[] = servesAllServices
        ? []
        : serviceIds.map((serviceId) => ({
            id: `tmp-${prof.id}-${serviceId}`,
            business_id: business.id,
            professional_id: prof.id,
            service_id: serviceId,
            created_at: new Date().toISOString(),
          }));

      setBusiness((prev) =>
        prev
          ? {
              ...prev,
              professionals: prev.professionals.map((p) =>
                p.id === prof.id ? { ...p, serves_all_services: servesAllServices } : p
              ),
              professional_services: [
                ...(prev.professional_services || []).filter((ps) => ps.professional_id !== prof.id),
                ...nextRows,
              ],
            }
          : prev
      );

      toast.success("Serviços do profissional atualizados.");
    } catch (err: any) {
      toast.error(err?.message || "Erro ao salvar serviços.");
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="mt-8 sm:mt-12">
      <h2 className="font-display text-lg font-semibold">Profissionais</h2>

      <div className="mt-4 space-y-3">
        {(business.professionals || []).map((prof) => {
          const selectedIds = servicesByProfessional.get(prof.id) || [];
          const isSaving = savingId === prof.id;
          const profInvite = staffInvites.find((si) => si.professional_id === prof.id && si.status !== "revoked");
          const isExpanded = inviteExpandedId === prof.id;

          return (
            <div key={prof.id} className={`rounded-xl border bg-card p-3 sm:p-4 ${prof.active ? "border-border" : "border-destructive/30 opacity-60"}`}>
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-semibold text-sm sm:text-base truncate">{prof.name}</p>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    {prof.working_hours_start} - {prof.working_hours_end} • {prof.active ? "Ativo" : "Inativo"}
                  </p>
                </div>

                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="icon" onClick={() => handleToggle(prof)} className={`h-8 w-8 ${prof.active ? "text-primary" : "text-muted-foreground"}`}>
                    {prof.active ? <UserCheck className="h-4 w-4" /> : <UserX className="h-4 w-4" />}
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(prof.id)} className="h-8 w-8 text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="mt-3 rounded-lg border border-border p-2.5 sm:p-3 space-y-3">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={prof.serves_all_services}
                    disabled={isSaving}
                    onChange={(e) =>
                      saveAssignments(
                        prof,
                        e.target.checked,
                        e.target.checked ? [] : selectedIds
                      )
                    }
                    className="h-4 w-4"
                  />
                  <span className="text-muted-foreground">Executa todos os serviços</span>
                </label>

                {!prof.serves_all_services && (
                  <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2 sm:gap-2">
                    {business.services.map((svc) => {
                      const checked = selectedIds.includes(svc.id);
                      return (
                        <label key={svc.id} className="flex items-center gap-2 text-sm rounded-md border border-border px-2 py-2 sm:py-1.5">
                          <input
                            type="checkbox"
                            checked={checked}
                            disabled={isSaving}
                            onChange={(e) => {
                              const next = e.target.checked
                                ? [...selectedIds, svc.id]
                                : selectedIds.filter((id) => id !== svc.id);
                              saveAssignments(prof, false, next);
                            }}
                            className="h-4 w-4"
                          />
                          <span className="text-muted-foreground">{svc.name}</span>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Commission section */}
              <CommissionSection
                prof={prof}
                business={business}
                commissionRules={commissionRules}
                onReload={loadCommissions}
              />

              {/* Extra hours section */}
              <div className="mt-3 pt-3 border-t border-border/50">
                <button
                  className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors w-full"
                  onClick={() => setExtraExpandedId(extraExpandedId === prof.id ? null : prof.id)}
                >
                  <Clock className="h-3.5 w-3.5 shrink-0" />
                  <span>Horários extras</span>
                  <span className="text-[10px] text-muted-foreground/50 ml-0.5 hidden sm:inline">(encaixes fora do expediente)</span>
                  {(extraHoursMap[prof.id] || []).length > 0 && (
                    <span className="ml-1 rounded-full bg-primary/15 px-1.5 py-0.5 text-[10px] font-medium text-primary">
                      {(extraHoursMap[prof.id] || []).length}
                    </span>
                  )}
                  {extraExpandedId === prof.id ? <ChevronUp className="h-3 w-3 ml-auto" /> : <ChevronDown className="h-3 w-3 ml-auto" />}
                </button>
                {extraExpandedId === prof.id && (
                  <div className="mt-2 space-y-2">
                    {(extraHoursMap[prof.id] || []).length === 0 ? (
                      <p className="text-xs text-muted-foreground/60 py-1">Nenhum horário extra configurado.</p>
                    ) : (
                      <div className="space-y-1">
                        {(extraHoursMap[prof.id] || []).sort((a, b) => a.day_of_week - b.day_of_week).map(eh => (
                          <div key={eh.id} className="flex items-center gap-2 text-xs bg-muted/40 rounded-lg px-2.5 py-1.5">
                            <span className="font-medium text-foreground w-16 shrink-0">{DAYS_FULL[eh.day_of_week]}</span>
                            <span className="text-muted-foreground">{eh.open_time} – {eh.close_time}</span>
                            <button
                              onClick={() => handleRemoveExtra(prof.id, eh.id)}
                              className="ml-auto text-destructive hover:text-destructive/80 transition-colors"
                              aria-label="Remover"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex flex-wrap gap-1.5 items-end pt-1 border-t border-border/30">
                      <Select value={String(newExtraDay)} onValueChange={v => setNewExtraDay(Number(v))}>
                        <SelectTrigger className="h-7 text-xs w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {DAYS_FULL.map((d, i) => (
                            <SelectItem key={i} value={String(i)}>{d}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input
                        type="time"
                        value={newExtraStart}
                        onChange={e => setNewExtraStart(e.target.value)}
                        className="h-7 w-24 text-xs"
                      />
                      <span className="text-xs text-muted-foreground">–</span>
                      <Input
                        type="time"
                        value={newExtraEnd}
                        onChange={e => setNewExtraEnd(e.target.value)}
                        className="h-7 w-24 text-xs"
                      />
                      <Button
                        size="sm"
                        className="h-7 text-xs bg-gradient-gold text-primary-foreground hover:opacity-90 px-2.5"
                        onClick={() => handleAddExtra(prof.id)}
                        disabled={savingExtra === prof.id}
                      >
                        {savingExtra === prof.id ? "..." : <><Plus className="h-3 w-3 mr-1" />Adicionar</>}
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {/* Staff invite section */}
              <div className="mt-3 pt-3 border-t border-border/50">
                {profInvite ? (
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <UserCog className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground truncate">{profInvite.invited_email}</span>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium border ${ROLE_COLORS[profInvite.role] ?? ""}`}>
                        {ROLE_LABELS[profInvite.role] ?? profInvite.role}
                        {profInvite.status === "pending" && " · Pendente"}
                      </span>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      {profInvite.status === "pending" && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 text-xs text-muted-foreground px-2"
                          onClick={() => copyInviteLink(profInvite.invite_token)}
                        >
                          <Link2 className="h-3 w-3 mr-1" /> Copiar link
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs text-destructive px-2"
                        onClick={() => handleRevoke(profInvite.id)}
                        disabled={revoking === profInvite.id}
                      >
                        {revoking === profInvite.id ? "..." : "Revogar"}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <button
                      className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                      onClick={() => { setInviteExpandedId(isExpanded ? null : prof.id); setInviteEmail(""); }}
                    >
                      <Mail className="h-3.5 w-3.5" />
                      Convidar para o painel
                      {isExpanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                    </button>
                    {isExpanded && (
                      <div className="mt-2 flex flex-col sm:flex-row gap-2">
                        <Input
                          type="email"
                          placeholder="email@exemplo.com"
                          value={inviteEmail}
                          onChange={(e) => setInviteEmail(e.target.value)}
                          className="h-8 text-xs flex-1"
                        />
                        <Select value={inviteRole} onValueChange={(v) => setInviteRole(v as "gerente" | "barbeiro")}>
                          <SelectTrigger className="h-8 text-xs w-full sm:w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="barbeiro">Barbeiro</SelectItem>
                            <SelectItem value="gerente">Gerente</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          size="sm"
                          className="h-8 text-xs bg-gradient-gold text-primary-foreground hover:opacity-90 px-3"
                          onClick={() => handleInvite(prof)}
                          disabled={inviting === prof.id}
                        >
                          {inviting === prof.id ? "..." : "Convidar"}
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 rounded-xl border border-dashed border-border p-3 sm:p-4">
        <div className="flex flex-col sm:flex-row sm:items-end gap-2 sm:gap-3">
          <div className="flex-1">
            <Label className="text-xs">Nome</Label>
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nome do profissional" className="mt-1" />
          </div>
          <div className="flex gap-2">
            <div className="flex-1 sm:w-28">
              <Label className="text-xs">Início</Label>
              <Input type="time" value={newStart} onChange={(e) => setNewStart(e.target.value)} className="mt-1" />
            </div>
            <div className="flex-1 sm:w-28">
              <Label className="text-xs">Fim</Label>
              <Input type="time" value={newEnd} onChange={(e) => setNewEnd(e.target.value)} className="mt-1" />
            </div>
          </div>
          <Button onClick={handleAdd} disabled={adding} size="sm" className="bg-gradient-gold text-primary-foreground h-9 w-full sm:w-auto">
            <Plus className="mr-1 h-4 w-4" /> Adicionar
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProfessionalsTab;
